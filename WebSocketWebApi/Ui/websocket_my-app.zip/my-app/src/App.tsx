import React, { useState, useEffect, useRef } from 'react';

interface RowData {
  id: number;
  status: string;
}

const WebSocketComponent: React.FC = () => {
  const [rows, setRows] = useState<RowData[]>([
    { id: 1, status: 'Inactive' },
    { id: 2, status: 'Inactive' },
    { id: 3, status: 'Inactive' },
    { id: 4, status: 'Inactive' },
  ]); // Initial data for the grid (4 rows with 'Pending' status)

  const wsRef = useRef<WebSocket | null>(null); // Reference to WebSocket instance

  useEffect(() => {
    // Establish WebSocket connection
    wsRef.current = new WebSocket('https://localhost:7016/gateway/v1/Onboarding/Websocket/init/2'); // Update with your server's WebSocket URL

    console.log("wsRef.current ====>>", wsRef.current);


    // WebSocket event handlers
    wsRef.current.onopen = () => {
      console.log('WebSocket connected');
    };

    wsRef.current.onmessage = (event: MessageEvent) => {
      // Parse the incoming message (JSON object containing 'id' and 'status')
      const message = JSON.parse(event.data);

      console.log("message ===>>>",message);
      
      // Update the status of the row with the corresponding 'id'
      setRows(prevRows => 
        prevRows.map(row =>
          row.id === message.id ? { ...row, status: message.status } : row
        )
      );
    };

    wsRef.current.onclose = () => {
      console.log('WebSocket disconnected');
    };

    wsRef.current.onerror = (error) => {
      console.error('WebSocket Error:', error);
    };

    // Clean up WebSocket connection when the component is unmounted
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [rows.length]); // Re-run effect when currentRowIndex or rows.length changes

  return (
    <div>
      <h1>Server Messages</h1>
      <div>
        <h3>Updating Row Status:</h3>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{row.id}</td>
                <td>{row.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default WebSocketComponent;
